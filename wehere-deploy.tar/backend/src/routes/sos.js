const express = require('express');
const router = express.Router();

router.get('/resources', (req, res) => {
  res.json({
    helplines: [
      { name: 'National Suicide & Crisis Lifeline', contact: '988', type: 'Call/Text' },
      { name: 'Vandrevala Foundation', contact: '+91 9999 666 555', type: 'Call' },
      { name: 'Crisis Text Line', contact: 'Text HOME to 741741', type: 'Text' },
      { name: 'AASRA Helpline', contact: '+91 98204 66726', type: 'Call' }
    ]
  });
});

module.exports = router;
